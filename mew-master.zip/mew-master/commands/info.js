exports.action = (msg) => {
    msg.channel.send('Welcome to the Mew DEX! Mew is your go-to resource for all things Pokémon-related.\nFor a list of useful commands, type `m.help`. ');
}
