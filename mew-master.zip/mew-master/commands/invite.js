exports.action = (msg, args) => {
    msg.channel.send("Mew is a private bot so you can't add it to your server...Sorry!");
}