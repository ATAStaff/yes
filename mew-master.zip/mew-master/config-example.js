module.exports = {
    token: 'NDA1NzE1Mzk4MTE0NDEwNDk2.DUqacQ.SU4HUni6WY-YWPwspbr7eIcUpiM',
    prefix: 'm.',
    ownerID: '111291959879983104'
}